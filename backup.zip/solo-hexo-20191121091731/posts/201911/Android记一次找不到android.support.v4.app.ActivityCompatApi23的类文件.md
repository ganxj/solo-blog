title: Android记一次找不到android.support.v4.app.ActivityCompatApi23的类文件
date: '2019-11-11 11:01:33'
updated: '2019-11-11 11:01:33'
tags: [Android, v4包]
permalink: /articles/2019/11/11/1573441293227.html
---
# Android记一次找不到android.support.v4.app.ActivityCompatApi23的类文件


原因是由于support v4包26版本之后已经没有android.support.v4.app.ActivityCompatApi23这个类了；

所以把v4包的版本改为
```
    implementation 'com.android.support:support-v4:26.1.0'
```
