title: Android 获取设备IP地址，wifi的数据的分开
date: '2019-10-25 16:15:14'
updated: '2019-10-25 17:14:34'
tags: [Android, ip地址, wifi, ipAddress]
permalink: /articles/2019/10/25/1571991313677.html
---
今天开发用到一个不常用的知识点，特此记录下，获取设备的IP地址。
话不多说，上代码，直接判断网络环境，获取对应的ip
```

    public static String getIPAddress(Context context) {
        NetworkInfo info = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();

        if (info != null && info.isConnected()) {
            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {//当前使用2G/3G/4G网络
                try {

                    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                        NetworkInterface intf = en.nextElement();
                        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                            InetAddress inetAddress = enumIpAddr.nextElement();
                            if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                return inetAddress.getHostAddress();
                            }
                        }
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                }

            } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {//当前使用无线网络
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String ipAddress = Formatter.formatIpAddress(wifiInfo.getIpAddress());
                return ipAddress;
            }
        } else {
            //未连接网络，提示用户
            Toast.makeText(context, "无网络", Toast.LENGTH_SHORT).show();
        }
        return null;
    }


```

得注意的是wifi环境下获取的ip的局域网的ip地址，并不是外网的地址，如需获取外网的地址还需请求额外的接口。
