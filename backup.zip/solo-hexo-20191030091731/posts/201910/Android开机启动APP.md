title: Android 开机启动APP
date: '2019-10-24 14:45:06'
updated: '2019-10-24 14:45:06'
tags: [Android, 开机启动, 广播, receiver]
permalink: /articles/2019/10/24/1571899506161.html
---
最近开发一个项目需要用到APP一开机启动，并且自己能运行。
# 一. 实现
继承一个BroadcastReceiver用来处理BOOT_COMPLETED广播消息
```

public class BootBroadcastReceiver extends BroadcastReceiver {
    /**
     * 可以实现开机自动打开软件并运行。
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        KLog.i("BootReceiver 收到广播  : " + action);
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            KLog.i("收到开机广播，启动程序");
            Intent thisIntent = new Intent(context, MainActivity.class);
            thisIntent.setAction("android.intent.action.MAIN");
            thisIntent.addCategory("android.intent.category.LAUNCHER");
            thisIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(thisIntent);
        }
    }
}

```
在AndroidManifest.xml中注册

```
        <receiver
            android:name=".receiver.BootBroadcastReceiver"
            android:enabled="true"
            android:exported="true">
            <intent-filter android:priority="2147483647">
                <!--注册开机广播地址-->
                <action android:name="android.intent.action.BOOT_COMPLETED"></action>
                <action android:name="android.media.AUDIO_BECOMING_NOISY" />
                <category android:name="android.intent.category.DEFAULT"/>
            </intent-filter>
        </receiver>
```

代码非常简单。。。但是！！有些手机会收不到广播。
# 二. 不能自动启动的原因
####  AndroidManifest.xml中BOOT_COMPLETED部分不正确，或者缺少必要的uses-permission。

####  应用安装到了sd卡内，安装在sd卡内的应用不能收到BOOT_COMPLETED。

####  系统开启了Fast Boot模式，这种模式下系统启动不会发送BOOT_COMPLETED。

####  应用程序安装后重来没有启动过，这种情况下应用程序接收不到任何广播，包括BOOT_COMPLETED、ACTION_PACKAGE_ADDED、CONNECTIVITY_ACTION等等。

所有，有些应用只有Background Service，而不包括任何Activity，是不能启动的。


还有一种情况。拿小米的手机为例，需要在应用信息页面打开自启动的按钮才可以实现开机自启动。所以需要多留意机型适配。
