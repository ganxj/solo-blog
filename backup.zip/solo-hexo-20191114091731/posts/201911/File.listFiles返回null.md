title: File.listFiles()返回null
date: '2019-11-12 15:42:42'
updated: '2019-11-12 15:42:42'
tags: [Android, file, 权限]
permalink: /articles/2019/11/12/1573544562117.html
---
# 问题描述

```
private static final String path;

File file= new File(path);
File[] files = file.listFiles(); // 得到null

```

如果已知`ROOT`路径存在，`file.exists()`返回`true`。且是文件夹。那么原因则是**没有获取`READ_EXTERNAL_STORAGE`权限**。

# 解决方法

如果是android6.0以前，在`AndroidManifest.xml`添加`<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>`即可。若在android6.0之后，则还要**动态申请权限**。

