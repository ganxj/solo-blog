title: Android 实现文件的读写
date: '2019-10-28 16:55:17'
updated: '2019-10-28 16:55:17'
tags: [Android, 文件写入, 文件读取, sdCard读数据]
permalink: /articles/2019/10/28/1572252917341.html
---
今天需要用到对文件的简单读写，发现以前居然没有整理过，虽然很简单，但是也记录下：

# 一、 权限

SD卡的读写权限

```
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
```
SD卡删除文件的权限
```
    <uses-permission android:name="android.permission.MOUNT_UNMOUNT_FILESYSTEMS" />
```

# 二、写数据

往里写入数据
```

    public static void writeSDFile(String fileName, String writeStr) {
        File file = new File(fileName);

        try {
            if (file.exists()) {
                file.delete();
            }
            file.createNewFile();
            FileOutputStream fos = new FileOutputStream(file);
            byte[] bytes = writeStr.getBytes();
            fos.write(bytes);
            fos.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

# 三、读数据

```

    public static String readFile(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            return "";
        }

        StringBuilder sb = new StringBuilder("");
        try {
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                //打开文件输入流
                FileInputStream inputStream = new FileInputStream(fileName);
                byte[] buffer = new byte[1024];
                int len = inputStream.read(buffer);
                //读取文件内容
                while (len > 0) {
                    sb.append(new String(buffer, 0, len));

                    //继续将数据放到buffer中
                    len = inputStream.read(buffer);
                }
                //关闭输入流
                inputStream.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

```


