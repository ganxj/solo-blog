title: 记 js判断数组是否包含某个元素
date: '2019-11-01 17:32:46'
updated: '2019-11-01 17:32:46'
tags: [js, 数组, 判断, 包含]
permalink: /articles/2019/11/01/1572600765857.html
---

1、list.indexOf()

```
let list = [1,2,3,4];
let index = list.indexOf(2);
console.log(index) //结果是2
```
这个方法会返回这个元素的下标，如果没有找到那就返回-1。根据这个判断是否存在就行了。


2、后来一看还有更简单的。

```
list.includes()
```

这个方法直接返回true或者false ，更加直接

还有其他方法，这里就不做深究了，以此记录
