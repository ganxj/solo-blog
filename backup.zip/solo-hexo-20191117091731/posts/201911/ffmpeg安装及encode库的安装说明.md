title: ffmpeg安装及encode库的安装说明
date: '2019-11-08 15:03:26'
updated: '2019-11-08 15:03:26'
tags: [ffmpeg, encode, 视频转码, Vp8]
permalink: /articles/2019/11/08/1573196605862.html
---
一、安装ffmpeg
A. 去ffmpeg官网（https://ffmpeg.org/）下载linux的官方源码包 
B. 解压 tar -jxvf ffmpeg-3.1.4.tar.bz2 
C. 进入解压目录 cd ffmpeg-3.1.4/ 
D. 执行 ./configure –enable-shared –prefix=/usr/local/ffmpeg

如果提示出错

yasm/nasm not found or too old. Use –disable-yasm for a crippled build.

If you think configure made a mistake, make sure you are using the latest 
version from Git. If the latest version fails, report the problem to the 
ffmpeg-user@ffmpeg.org mailing list or IRC #ffmpeg on irc.freenode.net. 
Include the log file “config.log” produced by configure as this will help 
solve the problem.

E.按照提示需要安装yasm. 
1).wget http://www.tortall.net/projects/yasm/releases/yasm-1.3.0.tar.gz 下载源码包 
2).tar zxvf yasm-1.3.0.tar.gz 解压 
3).cd yasm-1.3.0 进入目录 
4)../configure 配置 
5).make && make install 编译安装

安装完成后，继续执行 
./configure –enable-shared –prefix=/usr/local/ffmpeg 
然后 
F. make 这个编译的时间会很长 
G. make install 安装

最后 检查安装是否成功 
/usr/local/ffmpeg/bin/ffmpeg –version

报错如下 
/usr/local/ffmpeg/bin/ffmpeg: error while loading shared libraries: libavdevice.so.56: cannot open shared object file: No such file or directory

提示库文件找不到。 
修改文件/etc/ld.so.conf 内容增加/usr/local/ffmpeg/lib/

vim /etc/ld.so.conf

include ld.so.conf.d/*.conf 
/usr/local/ffmpeg/lib

保存退出之后 ，执行 
ldconfig 
使修改生效

执行 /usr/local/ffmpeg/bin/ffmpeg –version

配置环境变量 path 
执行 export PATH=/usr/local/ffmpeg/bin/:$PATH 
执行 env

则在任何目录都可以执行 ffmpeg –version

测试执行转码： 
ffmpeg -i test.avi test.mp4

到这里ffmpeg的安装就完成了，但是有很多的视频编码ffmpeg在现在的情况下是没法完成的，因为他有些编码库好没有装上去，下面就是讲编码库的安装

参考资料：http://blog.csdn.net/5iasp/article/details/50913855

二、安装ffmpeg的encode库
声明：安装ffmpeg或者encode库没有先后顺序，可以先安装ffmpeg的编码库 。ffmpeg编译是需要很长的时间的。这里根据需要我只讲h264 、theora、vp8 这三种编码的安装。如需其他的编码，可以找编码安装即可，方式相同 
1、安装h264编码库 
1).先下载x264的工程代码，h264 的编码库下载地址（git clone git://git.videolan.org/x264.git），linux系统有些是带git的，如果没有可以先安装一个 
执行 yum install git

2)进入x264文件夹，./configure –help看看它的帮助信息，我们这里需要的是x264以.so or .a的形式来支援ffmpeg，所以一般就关注shared和static关键词就可以了。执行./configure –enable-shared –enable-static就行了。 
3).完了make && make install就可以了。

你会发现我们在./configure的时候没有指定前缀–prefix=/usr，很明显，libx264.so和libx264.a就会复制到/usr/local/lib下去，记住这里，等下会因为这里要做一些修改。

重新编译ffmpeg（也可以先安装下边的两个包，到时候一起编译，节约时间） 
1).进入ffmpeg目录，./configure –enable-gpl –enable-libx264，然后就生成了新的makefile了。 
2).执行make clean 完了之后make 完了之后make install。 
3).这样ffmpeg就被重新编译了，完了就可以验证一下，使用ffmpeg工具，把某个视频文件中的视频流转码成h264格式

如果你看到类似于“libxxx.so找不到”的错误提示，解决方法 
在/etc/ld.so.conf文件中添加一行/usr/local/lib 保存退出之后ldconfig命令使得刚刚的修改生效，完了再运行转码命令试试

参考资料：http://blog.csdn.net/zmlcool/article/details/8141097

2、安装theora编码库 
安装theora编码库需要 ogg 的依赖 所以在这之前需要先安装ogg 
1)ogg的源码包下载地址：http://www.xiph.org/downloads/ 
2)tar -zxvf libogg-1.3.2.tar.gz 解压 
3)cd libogg-1.3.2/ 进入目录 
4)./configure 配置 
5)make 编译 
6)make install 安装

1) theora下载源码包，下载地址http://theora.org/downloads/ 
2) 解压 tar xvfj libtheora-1.1.1.tar.bz2 
3) 进入文件夹 cd libtheora-1.1.1/ 
4) ./configure 配置 
5) make 编译 
6) make install 安装

到此theora 编码库安装完成

重新编译ffmpeg（也可以先安装下边的两个包，到时候一起编译，节约时间） 
进入ffmpeg目录，./configure –enable-gpl –enable-libtheora –enable-libx264，然后就生成了新的makefile了。 
执行make clean 完了之后make 完了之后make install。

3、安装 vp8 编码库 
1)下载源码包:https://github.com/webmproject/libvpx/releases/tag/v1.6.0 
2)tar -zxvf libvpx-1.6.0.tar.gz. 
3)cd libvpx-1.6.0/ 
4)./configure 
5)make 
6)make install

Vp8 安装完成

重新编译ffmpeg（也可以先安装下边的两个包，到时候一起编译，节约时间） 
进入ffmpeg目录， 
./configure –enable-gpl –enable-libtheora –enable-libx264 –enable-libvpx，然后就生成了新的makefile了。 
执行make clean 完了之后make 完了之后make install。

现在ffmpeg能转的编码格式如下表，我们刚刚安装的三个格式都已经在里面了

三、使用方法
这是我使用的三种格式的转码方式

ffmpeg -i test.avi -vcodec libx264 -acodec aac testout.m4v 或者 ffmpeg -i test.avi -vcodec h264 -acodec aac testout.m4v

ffmpeg -i test.avi -vcodec libtheora -acodec vorbis -strict -2 testout.ogv

ffmpeg -i test.avi -vcodec vp8 -acodec vorbis -strict -2 testout.webm

还有分享这篇博客，上面有ffmpeg的更具体的使用方法 
http://www.cnblogs.com/wainiwann/p/4128154.html
